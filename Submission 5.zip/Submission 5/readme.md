Steps to execute the script

1. First the tables would be created from folder ->Submission5->Scripts->Table and Data Creation
2. Create the index ->Submission5->Scripts->Index
3. Create the Views ->Submission5->Scripts->Views
4. Create the Sequence ->Submission5->Scripts->Sequences
5. Create the Package ->Submission5->Scripts->Package ->Package Header after that execute Package Body
6. Create Procedures ->Submission5->Scripts->Procedures
7. Create Triggers ->Submission5->Scripts->Triggers
8. Create Users ->Submission5->Scripts->Users